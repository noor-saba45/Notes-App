import 'package:flutter/material.dart';
import 'package:notes/screens/sign_up_screen.dart';
import 'package:notes/screens/home_screen.dart';
class LoginScreen extends StatelessWidget {


  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        color: Colors.white,
        padding: EdgeInsets.symmetric(horizontal: 24),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Image.asset("images/log in.png"),

            Container(
              padding: EdgeInsets.symmetric(horizontal: 10),
              height: 40,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.deepPurpleAccent   .withOpacity(0.7),
                borderRadius: BorderRadius.circular(8),
                boxShadow: [BoxShadow(
                  color: Colors.blueGrey .withOpacity(0.3) ,
                  blurRadius: 20,
                  offset: Offset(0,10),
                ),
                ],
              ),
              child: Center(
                child: TextFormField(
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintText: "Enter Email",
                    prefixIcon: Icon(
                      Icons.person,
                      color: Colors.black.withOpacity(0.5),
                    ),
                  ),
                  cursorColor: Colors.black,
                ),
              ),
            ),
            SizedBox(height: 16),
            Container(
                padding: EdgeInsets.symmetric(horizontal: 10),
                height: 40,
                width: double.infinity,
                decoration: BoxDecoration(
                  color: Colors.deepPurpleAccent    .withOpacity(0.7),
                  borderRadius: BorderRadius.circular(8),
                  boxShadow: [BoxShadow(
                    color: Colors.blueGrey .withOpacity(0.3) ,
                    blurRadius: 20,
                    offset: Offset(0,10),
                  ),
                  ],

                ),
                child: Center(
                  child: TextFormField(
                    obscureText: true,
                    decoration: InputDecoration(
                      border: InputBorder.none,
                      hintText: "Enter Password",
                      prefixIcon: Icon(
                        Icons.lock,
                        color: Colors.black.withOpacity(0.5),
                      ),
                      suffixIcon: Icon(
                        Icons.remove_red_eye_outlined,
                        color: Colors.black.withOpacity(0.5),
                      ),
                    ),
                    cursorColor: Colors.black,
                  ),
                )),
            SizedBox(height: 40),
            InkWell(
                onTap: () {
                  // Simulating successful authentication
                  bool isAuthenticated = true; // Replace this with your actual authentication logic

                  if (isAuthenticated) {
                    // Navigate to the home screen upon successful authentication
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (context) => HomeScreen(),
                      ),
                    );
                  } else {
                    // Handle authentication failure (optional)
                  }
                },

              child: Container(
                  padding: EdgeInsets.symmetric(horizontal: 10),
                  height: 40,
                  width: double.infinity,

                  decoration: BoxDecoration(
                    color: Colors.deepPurpleAccent  ,

                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [BoxShadow(
                    color: Colors.black38 ,
                    blurRadius: 20,
                      offset: Offset(0,10),
                    ),
              ],
                  ),
                  child: Center(
                    child: Text(
                      "Log in ",

                      style: TextStyle(

                        fontSize: 19,
                        fontWeight: FontWeight.w600,
                        letterSpacing: 1,
                        wordSpacing: 2,
                      ),
                    ),
                  )),
            ),
            SizedBox(height  : 30),
            Row(
    mainAxisAlignment: MainAxisAlignment .center ,
              children:[
            Text(
              "Don't have an account? ",
              style: TextStyle(
                fontSize: 16,
                color: Colors.black .withOpacity(0.5),
              ),
            ),
                SizedBox(width   : 30),
    InkWell(onTap : (){
      Navigator.push(context , MaterialPageRoute(builder: (context) =>SignUpScreen (), ));
    } , child: Text(
    "Sign Up",
    style: TextStyle (
    color: Colors.deepPurpleAccent  ,
    fontSize: 18,
fontWeight: FontWeight .bold ,
    ),
    ),
    ) ,

          ],
        ),
        ],
      ),
      ),
    );
  }
}
